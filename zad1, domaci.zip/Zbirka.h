#ifndef ZBIRKA_H
#define ZBIRKA_H
#include "Karta.h"
#include "Borac.h"
class Zbirka
{
private:
	struct Elem {
		Karta* karta=nullptr;
		Elem* next = nullptr;
		Elem(Karta* k ) : karta(k) {}
	};
	Elem* prvi = nullptr, * poslednji = nullptr;
	void premesti(Zbirka& z);
	void kopiraj(const Zbirka& z);
	void brisi();

public:
	Zbirka() {}
	Zbirka(const Zbirka&);
	Zbirka(Zbirka&&);
	void  dodaj(Karta*);
	int getbroj() const;
	Zbirka& operator=(Zbirka&&);
	Zbirka& operator=(const Zbirka&);
	Karta* operator[](int indeks);
	Karta* kartaid(int id);
	const Karta* operator[](int indeks)const;
	Karta* operator()(int indeks);
	Karta* izbacikartu(int id);
	~Zbirka();
	Zbirka& operator~();
	friend ostream& operator<<(ostream& os, const Zbirka& z);
	Borac* minsnaga() const;
};

#endif;