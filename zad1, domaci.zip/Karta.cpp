#include "Karta.h"
#include<iostream>

int Karta::ID = 0;
ostream& operator<<(ostream& os, const Karta& k)
{
	k.pisi(os); return os;
	// TODO: insert return statement here
}

void Karta::pisi(ostream& os) const
{
	os << '[' << id << "]" << '"' << ime << '"' << "(cena:" << potrebna << ')';
}