#include "Zbirka.h"
#include <iostream>

void Zbirka::premesti(Zbirka& z)
{

	prvi = z.prvi; z.prvi = nullptr;
	poslednji = z.poslednji; z.poslednji = nullptr;

}

void Zbirka::kopiraj(const Zbirka& z)
{
	Elem* tek = z.prvi;
	while (tek) {
		Elem* novi = new Elem(tek->karta);
		if (prvi == nullptr) prvi = novi;
		else poslednji->next = novi;
		poslednji = novi;
		poslednji->next = nullptr;
		tek = tek->next;
	}
}

void Zbirka::brisi()
{
	while (prvi) {
		Elem* tek = prvi;
		prvi = prvi->next;
	 delete tek;
	}
}

Zbirka::Zbirka(const Zbirka& z)
{
	kopiraj(z);
}

Zbirka::Zbirka(Zbirka&& z)
{
	premesti(z);
}

void Zbirka::dodaj(Karta* K)
{

	Elem* novi = new Elem(K);
	if (prvi == nullptr)prvi = novi;
	else poslednji->next = novi;
	poslednji = novi;

}

int Zbirka::getbroj() const
{
	int n = 0;
	for (Elem* tek = prvi; tek; tek->next, ++n);
	return n;
}

Zbirka& Zbirka::operator=(Zbirka&& z)
{
	if (&z != this) {
		brisi();
		premesti(z);
	} return *this;
	
}

Zbirka& Zbirka::operator=(const Zbirka& z)
{
	if (&z != this) {
		brisi();
		kopiraj(z);
	}
	return *this;
}

Karta* Zbirka::operator[](int indeks)
{
	Elem* tek = prvi;
	for (int i = 0; tek && i != indeks; tek = tek->next, ++i);
	if (tek == nullptr) return nullptr;
	else return tek->karta;
}

Karta* Zbirka::kartaid(int i) {
	Elem* tek = prvi;
	for (tek = prvi; tek && tek->karta->getid() != i; tek = tek->next);
	if (tek == nullptr) return nullptr;
	else return tek->karta;
}
const Karta* Zbirka::operator[](int indeks) const
{
	
	Elem* tek = prvi;
	for (int i = 0; tek && i != indeks; tek = tek->next, ++i);
	if (tek == nullptr) return nullptr;
	else return tek->karta;

}

Karta* Zbirka::operator()(int indeks)
{
	Elem* tek = prvi, * preth = nullptr;
	for (int i=0; tek!=poslednji && i!=indeks; tek = tek->next,++i) {
		preth = tek;
	} 
	if (preth != nullptr && tek != nullptr) {
		preth->next = tek->next;
		tek->next = nullptr;
		Karta* k = tek->karta; delete tek;
		return k;
	}
	else if (tek == prvi && preth == nullptr) {
		Karta* k = prvi->karta;
		prvi = prvi->next; tek->next = nullptr;
		tek->karta = nullptr; delete tek;
		return k;
	}
	else if (tek == poslednji) {
		Karta* k = tek->karta; preth->next = nullptr;
		delete tek; return k;
	}
	else	return nullptr;
	
}

Karta* Zbirka::izbacikartu(int id)
{
	Elem* tek = prvi, * preth = nullptr;
	for (tek = prvi; tek!=poslednji && tek->karta->getid() != id; tek = tek->next) {
		preth = tek;
	}
	if (preth != nullptr && tek != nullptr) {
		preth->next = tek->next;
		tek->next = nullptr;
		Karta* k = tek->karta; delete tek;
		return k;
	}
	else if (tek == prvi && preth == nullptr) {
		Karta* k = prvi->karta;
		prvi = prvi->next; tek->next = nullptr;
		tek->karta = nullptr; delete tek;
		return k;
	}
	else if (tek == poslednji) {
		Karta* k = tek->karta; preth->next = nullptr;
		delete tek; return k;
	}
	else	return nullptr;

	
}

Zbirka::~Zbirka()
{
	brisi();
}

Zbirka& Zbirka::operator~()
{
	int broj = rand() % 10;
	Elem* tek = prvi, * preth = nullptr;
	for (tek = prvi; tek && tek->karta != (*this)[broj]; tek = tek->next) {
		preth = tek;
	} if (preth != nullptr && tek != nullptr) {
		preth->next = tek->next;
		tek->next = nullptr;
		delete tek;
	}return*this;


}


Borac* Zbirka::minsnaga() const
{
	Elem* tek = prvi;
	Borac* borac = nullptr;
	for (tek = prvi; tek && tek->karta->getkategorija() == Karta::BORAC; tek = tek->next) {
		Borac* b1 = static_cast<Borac*>(tek->karta);
		if (borac == nullptr) {
			borac = b1;
		}
			for (Elem* tek2 = tek->next; tek2 && tek2->karta->getkategorija() == Karta::BORAC; tek2 = tek2->next)
			{
				Borac* b2 = static_cast<Borac*>(tek2->karta);
				if (*b1 > * b2)
					borac = b2;
			}
	}
	return	borac;
}


ostream& operator<<(ostream& os, const Zbirka& z)
{
	Zbirka::Elem* tek = z.prvi;
	while (tek) {
		os << *tek->karta << endl;
		tek = tek->next;
	}

	return os;
}
