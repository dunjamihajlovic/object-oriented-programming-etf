#ifndef KARTA_H
#define KARTA_H
#include <string>
	using namespace std;
class Igrac;
class Karta
	{
	public:
		enum Kategorija { CAROLIJA, BORAC };
		Karta(string i, int medzik) : ime(i), potrebna(medzik) {}
		Karta(const Karta&) = delete;
		Karta(Karta&&) = delete;
		int getid() const { return id; }
		int getmagic() const { return potrebna; }
		string getime() const { return ime; }
		virtual Kategorija getkategorija() const = 0;
		virtual void upotrebi(Igrac* curr, Igrac* protivnik) = 0;
		virtual void pisi(ostream& os)const;
		friend ostream& operator<<(ostream& os, const Karta& k);
		virtual ~Karta() {}

	protected:
		mutable bool aktivno = false;
		string ime;
		int potrebna;
		static int ID;
		int id = ++ID;
};

#endif;