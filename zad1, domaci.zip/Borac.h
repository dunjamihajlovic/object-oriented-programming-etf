#ifndef BORAC_H
#define BORAC_H
#include "Karta.h"
class Borac : public Karta
{
protected:
	int snaga;
	const Kategorija kat = BORAC;
public:

	Borac(string i, int medzik, int s) : Karta(i, medzik), snaga(s) {}
	int getsnaga() const { return snaga; }
	virtual Kategorija getkategorija() const override { return kat; }
	friend bool operator>(const Borac& b1, const Borac& b2);
	virtual void upotrebi(Igrac* curr, Igrac* protivnik) override = 0;
	virtual void pisi(ostream& it) const override;
	virtual ~Borac() {}

};
#endif;
