#pragma once
#include "Karta.h"
class Carolija :public Karta
{
private: const Kategorija kat = CAROLIJA;
public:
	Carolija(string i, int medzik) : Karta(i, medzik) {}
	virtual Kategorija getkategorija() const  override { return kat; }

	virtual void upotrebi(Igrac* curr, Igrac* protivnik)override = 0;
};

