#ifndef CAROBNJAK_H
#define CAROBNJAK_H
#include "Karta.h"
#include "Borac.h"
class Carobnjak : public Borac
{

public:
	Carobnjak(string i, int medzik, int s) : Borac(i, medzik, s) {}
	int getsnaga() const { return snaga; }
	virtual Kategorija getkategorija() const override { return kat; }
	friend bool operator>(const Borac& b1, const Borac& b2);
	virtual void pisi(ostream& it) const override;
	virtual void upotrebi(Igrac* curr, Igrac* protivnik)  override;

};
#endif;
