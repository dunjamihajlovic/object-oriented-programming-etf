#include "Carobnjak.h"
#include <iostream>

void Carobnjak::pisi(ostream& it) const
{
	Borac::pisi(it);
	it << "-CAROBNJAK";
}