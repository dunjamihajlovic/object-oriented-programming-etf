#include "Igrac.h"

void Igrac::brisi()
{
	delete aktivirane; delete groblje; delete ruka;
	spil = nullptr; aktivirane = nullptr; ruka = nullptr; groblje = nullptr;
	life = 0; magic = 0; ime = "";
}

void Igrac::premesti(Igrac& i)
{
	spil = i.spil; i.spil = nullptr;
	aktivirane = i.aktivirane; i.aktivirane = nullptr;
	groblje = i.groblje; i.groblje = nullptr;
	ruka = i.ruka; i.ruka = nullptr;
	life = i.life;
	magic = i.magic;
	ime = i.ime;
	porazen = i.porazen;
}


void Igrac::kopiraj(const Igrac& i)
{
	spil = new Zbirka(*i.spil);
	aktivirane = new Zbirka(*i.aktivirane);
	groblje = new Zbirka(*i.groblje);
	ruka = new Zbirka(*i.ruka);
	life = i.life;
	magic = i.magic;
	ime = i.ime;
	porazen = i.porazen;
}

Igrac::Igrac(Igrac&& i)
{
	premesti(i);
}

Igrac::Igrac(const Igrac& i)
{
	kopiraj(i);
}

Igrac& Igrac::operator=(const Igrac& i)
{
	if (this != &i) {
		brisi();
		kopiraj(i);
	}return*this;
}

Igrac& Igrac::operator=(Igrac&& i)
{
	if (this != &i) {
		brisi();
		premesti(i);
	} return *this;
}

Igrac::~Igrac()
{
	brisi();
}

void Igrac::AktivirajIzRuke(int id_karte)
{
	if (!porazen) {
		Karta* k = ruka->kartaid(id_karte);

		if (k->getmagic() <= magic) {
			k = ruka->izbacikartu(id_karte);
			k->upotrebi(this, nullptr);
			if (aktivirane == nullptr) aktivirane = new Zbirka;
			aktivirane->dodaj(k);
		}

	}
}
void Igrac::setmagic(int b)
{
	magic = b;
}

void Igrac::setlife(int b)
{
	life = b;
	if (life <= 0) porazen = true;

}

void Igrac::vucikartu()
{
	if (!porazen) {
		Karta* k = (*spil)[0];
		if (!ruka) ruka = new Zbirka;
		ruka->dodaj(k);
	}
}


void Carobnjak::upotrebi(Igrac* curr, Igrac* protivnik) 
{
	if (!aktivno || protivnik == nullptr)
		aktivno = true;
	else
		if (*this > *protivnik->getaktivirane()->minsnaga()) {
			Borac* b = protivnik->getaktivirane()->minsnaga();
			int id = b->getid();
			protivnik->getgroblje()->dodaj (protivnik->getaktivirane()->izbacikartu(id));
			curr->setmagic(curr->magicna() - b->getmagic());
			protivnik->setlife(protivnik->zivotna() - 2 * b->getsnaga());

		}
}