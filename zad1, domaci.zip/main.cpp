#include "Karta.h"
#include "Carolija.h"
#include "Borac.h"
#include "Carobnjak.h"
#include "Zbirka.h"
#include "Igrac.h"
#include <iostream>
int main() {
	Carobnjak c1("bogotac", 300, 5000), c2("jocke", 200, 300), c3("aki", 300, 600), c4("ziza", 150, 30);
	Carobnjak c5("dragan", 50, 39), c6("nikola", 60, 20);
	Zbirka l1, l2, l5; 
	l1.dodaj(&c1);
	l1.dodaj(&c2);
	l1.dodaj(&c3);
	l1.dodaj(&c4);
	l2.dodaj(&c5);
	l2.dodaj(&c6);
	cout << l1 << endl;
	cout << l2 << endl;
	Igrac i1("prvi", 2000, 1000, &l1), i2("drugi", 300, 90, &l2);
	i1.vucikartu();
	i1.vucikartu();
	i2.vucikartu();
	i2.vucikartu();
	i1.AktivirajIzRuke(c1.getid());
	i2.AktivirajIzRuke(c5.getid());
	cout << *i1.getaktivirane();
	c1.upotrebi(&i1, &i2); 
	cout << *i2.getgroblje();





	return 0;
}	