#ifndef IGRAC_H
#define IGRAC_H
#include "Zbirka.h"
#include "Carobnjak.h"
class Igrac
{
private:
	bool porazen = false;
	string ime;
	int magic;
	int life;
	Zbirka* spil = nullptr;
	Zbirka* aktivirane = nullptr, * groblje = nullptr, * ruka = nullptr;
	void brisi();
	void kopiraj(const Igrac&);
	void premesti(Igrac&);

public:
	Igrac(string e, int medzik, int lajf, Zbirka* p) : ime(e), magic(medzik), life(lajf), spil(p) {
		ruka = new Zbirka();
		aktivirane = new Zbirka();
		groblje = new Zbirka();
	}
	/*Igrac(const Igrac& i) = delete;
	Igrac& operator=(const Igrac& i) = delete;*/
	Igrac(Igrac&&i);
	Igrac(const Igrac&i);
	Igrac& operator=(const Igrac& i);
	Igrac& operator=(Igrac&& i);
	~Igrac();
	string getime() const { return ime; }
	int magicna() const { return magic; }
	int zivotna() const { return life; }
	Zbirka* getpocetni() const { return spil; }
	Zbirka* getaktivirane() const { return aktivirane; }
	Zbirka* getgroblje() const { return groblje; }
	Zbirka* getruka() const { return ruka; }
	void AktivirajIzRuke(int);
	void setmagic(int b);
	void setlife(int b);
	void vucikartu();

};
#endif;
