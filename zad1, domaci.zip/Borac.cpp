#include "Borac.h"
#include <iostream>


void Borac::pisi(ostream& it) const
{
	Karta::pisi(it);
	it << "(snaga:" << snaga << ')';
}




bool operator>(const Borac& b1, const Borac& b2)
{
	return b1.snaga > b2.snaga;
}
