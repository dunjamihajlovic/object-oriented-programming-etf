#include "Mapa.h"
#include "PoljeSaSumom.h"
void Mapa::premesti(Mapa& mapa)
{
	mat = mapa.mat;
	mapa.mat = nullptr;
	m = mapa.m; n = mapa.n;
	mapa.m = 0;
	mapa.n = 0;
}

void Mapa::brisi()
{
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++)
		{
			delete mat[i][j];
		}
		delete[] mat[i];
	}
	delete[] mat; mat = nullptr; m = 0; n = 0;
}

void Mapa::kopiraj(const Mapa& mapa)
{m=mapa.m;
n=mapa.n;
mat = new Polje * *[m];
for (int i = 0; i < m; i++) {
	mat[i] = new Polje * [n];
	for (int j = 0; i < n; ++j) {
		mat[i][j] = mapa.mat[i][j]->kopija();
	}
}
}

Mapa::Mapa(int mm, int nn)
{
	m = mm; n = nn;
	mat = new Polje** [m];
	for (int i = 0; i < m; i++) {
		mat[i] = new Polje * [n];
		for (int j = 0; j < n; j++)
			mat[i][j] = new Polje;
	}
}

Mapa::Mapa(const Mapa& mapa)
{
	kopiraj(mapa);
}

Mapa::Mapa(Mapa&& mapa)
{
	premesti(mapa);
}

Mapa::~Mapa()
{
	brisi();
}

Mapa& Mapa::operator=(const Mapa& mapa)
{
	if (&mapa != this) { brisi(); kopiraj(mapa); }
	return *this;
}

Mapa& Mapa::operator=(Mapa&& mapa)
{
	if (&mapa != this) { brisi(); premesti(mapa); }
	return *this;
}

Mapa& Mapa::operator+=(unsigned int broj)
{
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			if ((mat[i][j]->getNeprohodnost() + broj)<=1000)
				for (int k = 0; k < broj; k++) (*mat[i][j])++;
		}
	}return *this;
}

Mapa& Mapa::operator-=(unsigned int broj)
{
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			if (mat[i][j]->getNeprohodnost() >= broj)
				for (int k = 0; k < broj; k++) (*mat[i][j])--;
		
		}
	}return *this;
}

Mapa& Mapa::zameniPolje(int i, int j,const  Polje& p)
{
	Polje* t = mat[--i][--j]; 
	mat[i][j]= p.kopija();
	while (mat[i][j]->getNeprohodnost() != t->getNeprohodnost()) {
		if (mat[i][j]->getNeprohodnost() > t->getNeprohodnost())
			(*mat[i][j])--;
		else (*mat[i][j])++;
	}
	delete t;
	return *this;

}

ostream& operator<<(ostream& os, const Mapa& mapa)
{
	for (int i = 0; i < mapa.m; i++) {
		for (int j = 0; j < mapa.n; j++) {
			os << *(mapa.mat[i][j]) << '\t';
		}os << endl;
	}return os;
}
