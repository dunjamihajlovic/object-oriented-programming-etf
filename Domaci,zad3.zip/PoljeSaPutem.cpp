#include "PoljeSaPutem.h"

char PoljeSaPutem::oznaka() const
{
	char p[2]{ 'Z','K' };
	return p[put];
}

PoljeSaPutem* PoljeSaPutem::kopija() const
{
	return new PoljeSaPutem(*this);
}
