#ifndef POLJE_H
#define POLJE_H
#include <iostream>
using namespace std;
class Polje
{
protected:
	unsigned int neprohodnost;
public:
	Polje(unsigned int i = 100);
	unsigned int getNeprohodnost() const { return neprohodnost; }
	Polje operator++(int);
	//Polje& operator++ ();
	Polje operator--(int);
	//Polje& operator-- ();
	friend ostream& operator<<(ostream& it, const Polje& p) ;
	virtual char oznaka() const { return 'P'; }
	virtual void pisi(ostream&) const ;
	virtual ~Polje() {}
	virtual Polje* kopija()const;
	//setnep
};
#endif
