#ifndef PUT_H
#define PUT_H
#include "Polje.h"
class PoljeSaPutem:public Polje
{
public: enum Put {ZEMLJANI,KAMENI};
	  PoljeSaPutem(unsigned int i, Put p) :Polje(i), put(p) {}
	  virtual char oznaka() const override;
	  virtual PoljeSaPutem* kopija()const override;
private: 
	Put put;
};
#endif
