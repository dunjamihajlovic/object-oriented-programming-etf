#ifndef MAPA_H
#define MAPA_H
#include "Polje.h"
#include "PoljeSaPutem.h"
#include "PoljeSaSumom.h"
class Mapa
{
private:
	Polje*** mat;
	int m, n;
	void premesti(Mapa&);
	void brisi();
	void kopiraj(const Mapa& mapa);

public:
	Mapa(int mm, int nn);
	Mapa(const Mapa& mapa);
	Mapa(Mapa&& mapa);
	~Mapa();
	Mapa& operator=(const Mapa& mapa);
	Mapa& operator=(Mapa&& mapa);
	Mapa& operator+=(unsigned int broj);
	Mapa& operator-=(unsigned int broj);
	Mapa& zameniPolje(int i, int j, const Polje& p);;
	friend ostream& operator<<(ostream& os, const Mapa& mapa);

};
#endif
