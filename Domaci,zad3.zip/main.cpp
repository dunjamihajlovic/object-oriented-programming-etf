#include "Polje.h"
#include "PoljeSaPutem.h"
#include"PoljeSaSumom.h"
#include "Mapa.h"
using namespace std;
int main() { 
	Polje p1(200), p2,p3;
	PoljeSaPutem pp1(300, PoljeSaPutem::Put::KAMENI), pp2(250, PoljeSaPutem::Put::ZEMLJANI);
	PoljeSaSumom ps1(400,20), ps2(500,40);
	cout << p1;
	cout << pp2;
	cout << ps1; cout << endl;
	Mapa m1(2, 3); m1 += 4;
	m1.zameniPolje(1, 1, pp1).zameniPolje(1, 2, ps2).zameniPolje(1,3,pp1).zameniPolje(2,2,pp1);
	m1 += 2;
	m1.zameniPolje(2, 3, ps2);
	cout << m1;
	cout << endl;
	return 0; }