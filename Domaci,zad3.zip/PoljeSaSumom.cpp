#include "PoljeSaSumom.h"

void PoljeSaSumom::pisi(ostream& it) const
{
	Polje::pisi(it);
	it << '(' << gustina << ')';
}

PoljeSaSumom* PoljeSaSumom::kopija() const
{
	return new PoljeSaSumom(*this);
}
