#ifndef SUMA_H
#define SUMA_H
#include "Polje.h"
class PoljeSaSumom:public Polje
{public:
	PoljeSaSumom(unsigned int i, int g) :Polje(i), gustina(g) {}
	virtual void pisi(ostream& it) const override;
	virtual char oznaka() const override { return 'S'; }
	virtual PoljeSaSumom* kopija()const override;
private:
	int gustina;
};

#endif