#include "Polje.h"

Polje::Polje(unsigned int i)
{
	if (i >= 0 && i <= 1000) neprohodnost = i;
	else neprohodnost = 100;
}

Polje Polje::operator++(int)
{Polje p = *this;
	if (neprohodnost < 1000)
		neprohodnost++; 
	return p;}


/*Polje& Polje::operator++()
{
	if (neprohodnost < 1000)
		neprohodnost++;
	return *this;
}*/

Polje Polje::operator--(int)
{Polje p = *this;
	if (neprohodnost > 0)
		neprohodnost--;
	return p;}

/*Polje& Polje::operator--()
{
	if (neprohodnost > 0)
		neprohodnost--; return *this;
}*/

void Polje::pisi(ostream& it) const
{
	it  <<oznaka() << '_' << neprohodnost;
}

Polje* Polje::kopija() const
{
	return new Polje(*this);
}

ostream& operator<<(ostream& it, const Polje& p)
{
	p.pisi(it);
	return it;
}
