#include "Obavestenje.h"
#include"Objava.h"
#include "Lista.h"
#include "Korisnik.h"


int main() {
	Objava o1(nullptr, "objava1"), o2(nullptr, "objava2"), o3(nullptr, "objava3");
	o2.procitaj();
	cout << o1 << endl;
	Lista l; l += &o1; l += &o2; l += &o3;
	cout << l << endl;
	Obavestenje* oo1; oo1 = l[2]; 
	cout << *oo1 << endl;
	Korisnik k1("pera"), k2("mika"), k3("zika");
	Objava o5(&k1, "nmg");
	k1.send(oo1, k2); k1.send(&o5, k2);
	k2.send(&o5, k3);
	cout <<k3<< endl;
	cout << k2 << endl;
	l += &o5; cout << l << endl;
	o1.procitaj(); l();
	cout << *l[2] << endl;
	l();
	cout << '\n'<<l;

	

	

	return 0;
}