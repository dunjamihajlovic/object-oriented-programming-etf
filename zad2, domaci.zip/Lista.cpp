#include "Lista.h"

void Lista::brisi()
{

	while (prvi) {
		Elem* tek = prvi;
		prvi = prvi->next;
		delete tek;
	}
}


Lista::~Lista()
{

	~*this;
	brisi();
}

Lista& Lista::operator+=(const Obavestenje* ob)
{
	Elem* novi = new Elem(ob->kopija());
	if (prvi == nullptr) { prvi = novi; poslednji = prvi; }
	else { Elem* t = prvi; prvi = novi; prvi->next = t; t = nullptr; }
	return *this;
	// TODO: insert return statement here
}

Lista& Lista::operator~()
{
	Elem* tek = prvi;
	while (tek) {
		Elem* pom = tek;
		tek = tek->next;
		delete pom->o;
		pom->o = nullptr;

	}
 return*this;
}

void Lista::operator()() const
{
	Elem* tek = prvi;
	while (tek) {
		if (!tek->o->getread()) cout << *(tek->o) << endl;
		tek = tek->next;
	}
}

int Lista::operator+() const
{
	int n = 0;
	Elem* tek = prvi;
	while (tek) {
		if (!tek->o->getread()) n++;
		tek = tek->next;
	} return n;
}

int Lista::operator!() const
{
	int n = 0;
	Elem* tek = prvi;
	while (tek) {
		if (tek->o->getread()) n++;
		tek = tek->next;
	} return n;
}

Obavestenje* Lista::operator[](int idd)
{
	Elem* tek;
	for (tek = prvi; tek && (tek->o->getid() != idd); tek = tek->next);
	if (tek != nullptr) return tek->o;
	else cout << "nema tog id-a"; return nullptr;

}

const Obavestenje* Lista::operator[](int idd) const
{
	Elem* tek;
	for (tek = prvi; tek && (tek->o->getid() != idd); tek = tek->next);
	if (tek != nullptr) return tek->o;
	else cout << "nema tog id-a"; return nullptr;
}

ostream& operator<<(ostream& it, const Lista& l)
{
	for (Lista::Elem* tek = l.prvi; tek; tek = tek->next) {
		it << *(tek->o) << endl;
	}return it;
	// TODO: insert return statement here
}