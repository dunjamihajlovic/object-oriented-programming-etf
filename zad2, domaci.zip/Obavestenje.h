#ifndef OBAVESTENJE_H
#define OBAVESTENJE_H
#pragma warning(disable : 4996)
#include <ctime>
#include <iostream>
	using namespace std;
	class Korisnik;
class Obavestenje
	{
	protected: Korisnik* kreator;
			 static int ID;
			 int id = ++ID;
			 
			time_t now = time(0);
			tm* t = localtime(&now);
				  int hh = t->tm_hour;
				  int mm = t->tm_min;
				  int ss = t->tm_sec;
			 bool procitano = false;

	public:
		Obavestenje(const Obavestenje& o) : id(o.id), kreator(o.kreator) {}
		Obavestenje(Obavestenje&& o) : id(o.id), kreator(o.kreator){}
		Obavestenje& operator=(const Obavestenje& o) { return*this; }
		Obavestenje& operator=(Obavestenje&& o) { return*this; }
		Obavestenje(Korisnik* k=nullptr) : kreator(k) {}
		void pisivreme(ostream& it) const;
		int getid() const { return id; }
		Korisnik* getkorisnik() const { return kreator; }
		void procitaj() { procitano = true; }
		bool getread() const { return procitano; }
		void setkreator(Korisnik* k) { kreator = k; }
		friend ostream& operator<<(ostream& it, const Obavestenje& o);
		virtual ~Obavestenje() {}
		virtual string specdeo() const = 0;
		virtual Obavestenje* kopija() const= 0;
		
	};


#endif;