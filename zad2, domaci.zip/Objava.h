#ifndef OBJAVA_H
#define OBJAVA_H
#include "Obavestenje.h"
class Objava :public Obavestenje
{
public:
	Objava(Korisnik* k, const string& t) : Obavestenje(k), tekst(t) { }
	virtual string specdeo() const override;
	virtual Objava* kopija() const override;
private:
	string tekst;
};
#endif;

