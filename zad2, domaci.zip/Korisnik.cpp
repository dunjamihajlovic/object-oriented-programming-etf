#include "Korisnik.h"

void Korisnik::send(Obavestenje* ob, Korisnik& k)
{
		ob->setkreator(this);

	if (!k.lista) { k.lista = new Lista; }
	//*k.lista += ob;
	k.take(ob, k);
}

void Korisnik::take(Obavestenje* ob, Korisnik& k)
{
	*lista += ob;
	ob->setkreator(&k);
}


ostream& operator<<(ostream& os, const Korisnik& k)
{
	return os << k.korisnickoIme << ' ' << *(k.lista);
}
ostream& operator<<(ostream& it, const Obavestenje& o)
{
	it << o.id << '|';
	it << ((o.kreator != nullptr) ? o.kreator->getime() : "___");
	o.pisivreme(it);
	it << ' ' << o.specdeo();
	return it;
}