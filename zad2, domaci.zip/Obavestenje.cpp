#include "Obavestenje.h"
#include <string>
int Obavestenje::ID = 0;

void Obavestenje::pisivreme(ostream& it) const
{
	it <<hh << ":" << mm << ':' << ss;
}
