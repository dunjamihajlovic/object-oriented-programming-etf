#ifndef LISTA_H
#define LISTA_H
#include "Obavestenje.h"

class Lista
{
private:
	struct Elem {
		Obavestenje* o;
		Elem* next;
		Elem(Obavestenje* ob) :o(ob), next(nullptr) {}
	};
	Elem* prvi = nullptr, * poslednji = nullptr;
	void brisi();
public:
	Lista() {}
	Lista(const Lista&) = delete;
	Lista(Lista&&) = delete;
	~Lista();
	Lista& operator+=(const Obavestenje* ob);
	Lista& operator~();
	void operator()() const;
	int operator+()const;
	int operator!() const;
	Obavestenje* operator[](int idd);
	const Obavestenje* operator[](int idd) const;
	friend ostream& operator<<(ostream& it, const Lista& l);

};
#endif;