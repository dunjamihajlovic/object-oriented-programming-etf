#include "Objava.h"

string Objava::specdeo() const
{
	return tekst;
}

Objava* Objava::kopija()const 
{
	return new Objava(*this);
}
