#ifndef KORISNIK_H
#define KORISNIK_H
#include "Obavestenje.h"
#include "Lista.h"
class Korisnik
{
private: string korisnickoIme;
	   Lista* lista = nullptr;
public:
	Korisnik(string i) : korisnickoIme(i) {}
	Korisnik(const Korisnik&) = delete;
	Korisnik& operator=(const Korisnik&) = delete;
	~Korisnik() { delete lista; }
	string getime()const { return korisnickoIme; }
	void send(Obavestenje* ob, Korisnik& k);
	void take(Obavestenje* ob, Korisnik& k);
	friend ostream& operator<< (ostream& os, const Korisnik& k);
	

};
#endif;
